# What's New

For information on what's new please refer to the [Releases page](https://github.com/Azure/alz-monitor/releases).
